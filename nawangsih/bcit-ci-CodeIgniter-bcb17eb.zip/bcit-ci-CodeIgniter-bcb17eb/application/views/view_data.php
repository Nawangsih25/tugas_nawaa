<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>berada di data</h1>

    <table border="1">
        <tr>
            <th>id</th>
            <th>nama</th>
            <th>kelas</th>
        </tr>
         <?php foreach ($query as $query) { ?>
        <tr>
               <td> <?= $query->id ?></td>
               <td> <?= $query->nama ?></td>
               <td> <?= $query->kelas ?></td>
        </tr>
       <?php } ?>
    </table>
    
</body>
</html>