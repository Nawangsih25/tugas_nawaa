<?php
// defined('BASEPATH') OR exit('No direct script access allowed');

// class tampil extends CI_Controller {

// 	public function data($data)
// 	{
//         echo $data;
// 		// $this->load->view('welcome_message');
//         // $this->load->view('view.login.php');
// 	}
//     public function tampil(){
//         $data['judul'] = "halamanjudul";
//         $data['deskripsi'] = "Lorem ipsum dolor sit amet consectetur adipisicing elit. Ducimus cupiditate eos velit consequuntur fugiat consequatur non itaque tenetur vitae aspernatur porro sapiente optio modi quis placeat facere, illo dolores suscipit.";

//         // parsing data
//         $this->load->view('tampil',$data);
        
//     }

//     public function nawang(){
//         echo "halooo selamat";
//     }

// }
