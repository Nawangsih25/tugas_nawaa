<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class login extends CI_Controller {

	// public function nawa()
	// { 
	// 	// $query['query'] =$this->db->get('login')->result();
	// 	// // $this->load->view('welcome_message');
    //     // $this->load->view('view_login.php', $query);

	// }
	public function index()
	{
		$this->load->view('view.login.php');
	}
}