<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class data extends CI_Controller {

	public function nawa()
	{
		$query['query'] =$this->db->get('wawa')->result();
		// $this->load->view('welcome_message');

        $this->load->view('view_data', $query);
	}
}