<!DOCTYPE html>
<html lang="en">
<head>
<title>sekolah</title>
</head>
<body>
    </head>
    <style>
        *{
    margin: 0;
    padding: 0;
    outline: 0;
    font-family: 'Open Sans', sans-serif;
}
body{
    height: 100vh;
    background-image: url(https://www.smkmutucikampek.sch.id/wp-content/uploads/2020/02/bg-masthead-1024x536.jpg);
    background-size: cover;
    background-position: center;
    background-repeat: no-repeat;
}

.container{
    position: absolute;
    left: 50%;
    top: 50%;
    transform: translate(-50%,-50%);
    padding: 20px 25px;
    width: 300px;

    background-color: rgba(165, 223, 214, 0.7);
    box-shadow: 0 0 10px rgba(255,255,255,.3);
}
.container h1{
    text-align: left;
    color: #161817;
    margin-bottom: 30px;
    text-transform: uppercase;
    border-bottom: 4px solid #0e1013;
}
.container label{
    text-align: left;
    color: #5f7f9a;
}
.container form input{
    width: calc(100% - 20px);
    padding: 8px 10px;
    margin-bottom: 15px;
    border: none;
    background-color: transparent;
    border-bottom: 2px solid #111112;
    color: rgb(173, 53, 151);
    font-size: 20px;
}
.container form button{
    width: 100%;
    padding: 5px 0;
    border: none;
    background-color:#47d35c;
    font-size: 18px;
    color: #121111;
}
  
    </style>
</head>
<body>
        <div class="container">
    <h1> Silahkan lakukan login</h1>
        <form>
        <div>
        id: <input type="text" name="id"  required>
        </div>
        <br>
        <div>
        nama: <input type="text" name="nama" required>
        </div>
        
        <button type="submit">save</button> 
        
        
    </form>
    <!-- <button type="submit">Delete</button> <button type="submit">Update</button> -->
</body>
</html>